# Projectweek 0
## Jonas Van Mullem

### Dag 1 (maandag 06/07):
- controle toegevoegd op int.
- had problemen met de incriptie maar heb het op kunnen lossen.
- heb het loginsysteem geïmplementeerd
- heb gaming menu gemaakt
- user aangemaakt
- deck aangemaakt

### Dag 2 (Dinsdag 07/07):
- blackjack afgemaakt

### Dag 3 (Woensdag 08/07):
- Memory aangemaakt
- Memory afgemaakt 
- Slot machine aangemaakt
- slot machine afgemaakt

### Dag 4 (Vrijdag 09/07):
- menu's aangepast zodat je ze navigeerd met pijntjes en dan enter